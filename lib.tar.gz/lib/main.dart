import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'app/core/app_router.dart';
import 'app/core/service_locator.dart';

void main() {
  // التأكد من تهيئة كل شيء قبل تشغيل التطبيق
  WidgetsFlutterBinding.ensureInitialized();
  // إعداد محدد موقع الخدمة (GetIt)
  setupLocator();
  // تشغيل التطبيق مع تفعيل Riverpod
  runApp(
    const ProviderScope(
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      // استخدام نظام التنقل GoRouter
      routerConfig: router,
      title: 'منظومة الحجوزات',
      theme: ThemeData(
        primarySwatch: Colors.teal,
        fontFamily: 'Cairo', // استخدام الخط العربي الذي عرفناه
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      debugShowCheckedModeBanner: false,
      // إعدادات دعم اللغة العربية
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('ar', 'SA'), // العربية
      ],
      locale: const Locale('ar', 'SA'),
    );
  }
}
