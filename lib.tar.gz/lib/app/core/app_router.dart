import 'package:go_router/go_router.dart';
import '../presentation/screens/dashboard/dashboard_screen.dart'; // سننشئ هذا الملف قريباً

final router = GoRouter(
  initialLocation: '/dashboard', // تحديد الشاشة الافتراضية
  routes: [
    GoRoute(
      path: '/dashboard',
      builder: (context, state) => const DashboardScreen(),
    ),
    // هنا سنضيف مسارات الشاشات الأخرى لاحقاً
    // GoRoute(path: '/customers', ...),
    // GoRoute(path: '/bookings', ...),
  ],
);
