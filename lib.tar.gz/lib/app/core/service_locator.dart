import 'package:get_it/get_it.dart';
import '../services/isar_service.dart'; // استيراد الخدمة الجديدة

final locator = GetIt.instance;

void setupLocator() {
  // تسجيل خدمة Isar كـ Lazy Singleton
  locator.registerLazySingleton<IsarService>(() => IsarService());
}
