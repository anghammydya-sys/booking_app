import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import '../data/collections/schemas.dart'; // استيراد ملف schemas الجديد

class IsarService {
  late Future<Isar> db;

  IsarService() {
    db = openDB();
  }

  Future<Isar> openDB() async {
    if (Isar.instanceNames.isEmpty) {
      final dir = await getApplicationDocumentsDirectory();
      return await Isar.open(
        [
          // إضافة كل الـ Schemas هنا
          CustomerSchema,
          VenueSchema,
          InventoryItemSchema,
          BookingSchema,
          BookingDetailSchema,
          PaymentSchema,
        ],
        directory: dir.path,
        inspector: true, // مفيد للتصحيح في وضع التطوير
      );
    }
    return Future.value(Isar.getInstance());
  }
}
