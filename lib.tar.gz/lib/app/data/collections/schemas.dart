import 'package:isar/isar.dart';

part 'schemas.g.dart';

@collection
class Customer {
  Id id = Isar.autoIncrement;
  late String name;
  @Index(unique: true)
  late String phone;
  String? notes;
}

@collection
class Venue {
  Id id = Isar.autoIncrement;
  @Index(unique: true)
  late String name;
  late String type;
}

@collection
class InventoryItem {
  Id id = Isar.autoIncrement;
  @Index(unique: true)
  late String name;
  late String category;
  late int totalQuantity;
}

@collection
class Booking {
  Id id = Isar.autoIncrement;
  @Index(unique: true)
  late String bookingNumber;
  late DateTime eventDate;
  late String eventType;
  @Index()
  String status = 'جاري';
  double totalAmount = 0.0;
  double paidAmount = 0.0;

  final customer = IsarLink<Customer>();
  final venue = IsarLink<Venue>();

  @Backlink(to: "bookingLink") // <-- تعديل هنا
  final details = IsarLinks<BookingDetail>();

  @Backlink(to: "bookingLink") // <-- تعديل هنا
  final payments = IsarLinks<Payment>();
}

@collection
class BookingDetail {
  Id id = Isar.autoIncrement;
  late int quantity;
  late double price;

  // --- تعديل هنا ---
  @Name("inventoryItem") // نحافظ على الاسم القديم في قاعدة البيانات
  final itemLink = IsarLink<InventoryItem>(); // نغير اسم الحقل في Dart

  @Index()
  final bookingLink = IsarLink<Booking>(); // <-- تعديل هنا
  // --- نهاية التعديل ---
}

@collection
class Payment {
  Id id = Isar.autoIncrement;
  late DateTime paidAt;
  late double amount;
  late String method;

  @Index()
  final bookingLink = IsarLink<Booking>(); // <-- تعديل هنا
}
