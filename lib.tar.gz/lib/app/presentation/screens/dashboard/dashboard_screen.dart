import 'package:booking_system/app/presentation/providers/database_providers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'widgets/nav_card.dart';
import 'widgets/stat_card.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // في المستقبل، سنقرأ البيانات الحقيقية من قاعدة البيانات هنا
  
     final bookingsCount = ref.watch(bookingsStreamProvider).asData?.value.length ?? 0;
    final customersCount = ref.watch(customersStreamProvider).asData?.value.length ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة التحكم'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle_outline),
            tooltip: 'حجز جديد',
            onPressed: () { /* سيتم تفعيله لاحقاً */ },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('نظرة عامة سريعة', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: StatCard(
                    title: 'إجمالي الحجوزات',
                    value: bookingsCount.toString(),
                    icon: Icons.event_note_rounded,
                    color: Colors.blue,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: StatCard(
                    title: 'إجمالي العملاء',
                    value: customersCount.toString(),
                    icon: Icons.groups_rounded,
                    color: Colors.green,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Text('إدارة النظام', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 1.2,
              children: [
                NavCard(title: 'الحجوزات', icon: Icons.calendar_today_rounded, color: Colors.orange, onTap: () { /* context.go('/bookings') */ }),
                NavCard(title: 'العملاء', icon: Icons.contact_page_rounded, color: Colors.cyan, onTap: () { /* context.go('/customers') */ }),
                NavCard(title: 'القاعات والأماكن', icon: Icons.store_mall_directory_rounded, color: Colors.red, onTap: () { /* context.go('/venues') */ }),
                NavCard(title: 'المخزون', icon: Icons.inventory_2_rounded, color: Colors.purple, onTap: () { /* context.go('/inventory') */ }),
              ],
            )
          ],
        ),
      ),
    );
  }
}
