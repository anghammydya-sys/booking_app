import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:isar/isar.dart';
import '../../core/service_locator.dart';
import '../../data/collections/schemas.dart'; // استيراد مخططات Isar
import '../../services/isar_service.dart'; // استيراد خدمة Isar

// 1. مزود للوصول إلى كائن Isar نفسه
// هذا الـ Provider يطلب كائن Isar من خدمة Isar التي سجلناها في GetIt
final isarProvider = FutureProvider<Isar>((ref) async {
  final isarService = locator<IsarService>();
  return await isarService.db;
});

// 2. مزودات لمراقبة المجموعات (Collections)
// StreamProvider يستمع إلى استعلام ويعيد بناء الواجهة عند تغير النتائج

final customersStreamProvider = StreamProvider<List<Customer>>((ref) {
  // انتظر حتى يصبح Isar جاهزًا
  final isar = ref.watch(isarProvider).asData?.value;
  if (isar == null) {
    return Stream.value([]); // أعد مجرى فارغًا إذا لم تكن قاعدة البيانات جاهزة
  }
  // قم ببناء استعلام لمراقبة كل العملاء
  return isar.customers.where().watch(fireImmediately: true);
});

final bookingsStreamProvider = StreamProvider<List<Booking>>((ref) {
  final isar = ref.watch(isarProvider).asData?.value;
  if (isar == null) {
    return Stream.value([]);
  }
  // قم ببناء استعلام لمراقبة كل الحجوزات
  return isar.bookings.where().watch(fireImmediately: true);
});

// يمكنك إضافة مزودات لبقية المجموعات بنفس الطريقة
final venuesStreamProvider = StreamProvider<List<Venue>>((ref) {
  final isar = ref.watch(isarProvider).asData?.value;
  if (isar == null) return Stream.value([]);
  return isar.venues.where().watch(fireImmediately: true);
});

final inventoryStreamProvider = StreamProvider<List<InventoryItem>>((ref) {
  final isar = ref.watch(isarProvider).asData?.value;
  if (isar == null) return Stream.value([]);
  return isar.inventoryItems.where().watch(fireImmediately: true);
});
